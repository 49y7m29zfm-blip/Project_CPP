#include <array>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

constexpr int NOTE_MIN = 0;
constexpr int NOTE_MAX = 20;
constexpr int NB_MENTIONS = 5;
constexpr int NB_ETUDIANTS_MAX = 200;

enum class Mention : std::size_t { Ajourne, Passable, AssezBien, Bien, TresBien };

Mention mentionPour(double n) {
    if (n < 10.0) return Mention::Ajourne;
    if (n < 12.0) return Mention::Passable;
    if (n < 14.0) return Mention::AssezBien;
    if (n < 16.0) return Mention::Bien;
    return Mention::TresBien;
}

std::string libelle(Mention m) {
    switch (m) {
        case Mention::Ajourne: return "Ajourne";
        case Mention::Passable: return "Passable";
        case Mention::AssezBien: return "Assez bien";
        case Mention::Bien: return "Bien";
        case Mention::TresBien: return "Tres bien";
    }
    return "Inconnue";
}

int lireEntier(const std::string& message, int min, int max) {
    while (true) {
        std::cout << message;
        std::string ligne;
        if (!std::getline(std::cin, ligne)) std::exit(EXIT_FAILURE);
        std::istringstream flux(ligne);
        int valeur = 0;
        char reste = '\0';
        if ((flux >> valeur) && !(flux >> reste)) {
            if (valeur >= min && valeur <= max) return valeur;
            std::cout << "Erreur : valeur entre " << min << " et " << max << ".\n";
        } else {
            std::cout << "Erreur : entrez un entier valide.\n";
        }
    }
}

double lireNote(int numero) {
    while (true) {
        std::cout << "Note de l'etudiant " << numero << " : ";
        std::string ligne;
        if (!std::getline(std::cin, ligne)) std::exit(EXIT_FAILURE);
        for (char& c : ligne) if (c == ',') c = '.';
        std::istringstream flux(ligne);
        double note = 0.0;
        char reste = '\0';
        if ((flux >> note) && !(flux >> reste) && std::isfinite(note)) {
            if (note >= NOTE_MIN && note <= NOTE_MAX) return note;
            std::cout << "Erreur : note comprise entre 0 et 20.\n";
        } else {
            std::cout << "Erreur : note invalide (exemple : 12,5).\n";
        }
    }
}

int main() {
    std::cout << "=== TP 3 : STATISTIQUES D'UNE SERIE DE NOTES ===\n";
    std::cout << "Nom de l'UE : ";
    std::string nomUE;
    if (!std::getline(std::cin, nomUE)) return EXIT_FAILURE;

    const int n = lireEntier("Nombre d'etudiants (1 a 200) : ", 1, NB_ETUDIANTS_MAX);
    std::array<double, NB_ETUDIANTS_MAX> notes{};
    std::array<int, NB_MENTIONS> effectifs{};

    double somme = 0.0, minimum = 20.0, maximum = 0.0;
    for (int i = 0; i < n; ++i) {
        const double note = lireNote(i + 1);
        notes[static_cast<std::size_t>(i)] = note;
        somme += note;
        if (note < minimum) minimum = note;
        if (note > maximum) maximum = note;
        ++effectifs[static_cast<std::size_t>(mentionPour(note))];
    }

    const double moyenne = somme / static_cast<double>(n);
    double sommeCarres = 0.0;
    for (int i = 0; i < n; ++i) {
        const double ecart = notes[static_cast<std::size_t>(i)] - moyenne;
        sommeCarres += ecart * ecart;
    }
    const double ecartType = std::sqrt(sommeCarres / static_cast<double>(n));
    const int admis = n - effectifs[static_cast<std::size_t>(Mention::Ajourne)];
    const double pourcentage = 100.0 * static_cast<double>(admis) / static_cast<double>(n);

    std::cout << "\n=== RESULTATS STATISTIQUES ===\n"
              << "UE : " << nomUE << '\n'
              << "Nombre d'etudiants : " << n << '\n'
              << std::fixed << std::setprecision(2)
              << "Note minimale : " << minimum << "/20\n"
              << "Note maximale : " << maximum << "/20\n"
              << "Moyenne : " << moyenne << "/20\n"
              << "Ecart-type : " << ecartType << '\n'
              << "Nombre d'admis : " << admis << '\n'
              << "Pourcentage d'admis : " << pourcentage << "%\n"
              << "\n=== REPARTITION PAR MENTION ===\n";

    for (int i = 0; i < NB_MENTIONS; ++i) {
        const auto m = static_cast<Mention>(i);
        const int effectif = effectifs[static_cast<std::size_t>(i)];
        std::cout << std::left << std::setw(15) << libelle(m)
                  << " : " << effectif << " | "
                  << std::string(static_cast<std::size_t>(effectif), '*') << '\n';
    }
    return EXIT_SUCCESS;
}
